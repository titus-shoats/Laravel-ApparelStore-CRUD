@extends('layout')

@section('content')
  <div class="row">

      <div class="table_container">
      	<h2>Edit Products</h2>

               


  	    	<table class="table  table-responsive">
				   <thead>
				   	  <tr>
				   	  	  <th>Delete Product</th>
				   	  	  
				   	  </tr>
				   </thead>

				   <tbody>
				   	  <tr>
				   	  	<td>
				   	  		<form action="" enctype="form-data">
				   	  			 <input type="submit" name="delete_product">
				   	  		</form>
				   	  	</td>
				   	  </tr>                     
				   </tbody>
					
	</table>
      </div>
  	      
  	    
  </div>
	


@stop