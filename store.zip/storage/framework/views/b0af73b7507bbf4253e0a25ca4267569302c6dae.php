<?php $__env->startSection('content'); ?>
  <div class="row">

      <div class="table_container">
      	<h2>Edit Products</h2>
      	<div>
      		<a class="btn btn-primary" href="http://localhost:8000/admin/add">Add New Product</a>
      	</div>

               


  	    	<table class="table  table-responsive">
				   <thead>
				   	  <tr>
				   	  	  <th>Product ID</th>
				   	  	  <th>Product Name</th>
				   	  	  <th>Product Price</th>
				   	  	  <th>Product Desc</th>
				   	  	  <th>Size</th>
				   	  	  <th>Product Image</th>
				   	  	   <th>Created Time</th>
				   	  	   <th>Updated Time</th>
				   	  	  <th> Category</th>
				   	  	  <th>Subcategory</th>
				   	  	  <th>Edit</th>
				   	  	  <th>Delete</th>
				   	  </tr>
				   </thead>

				   <tbody>
				   	 


                        <?php $__currentLoopData = json_decode($product); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                         <tr>
	                         <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>



	                             
	                             <?php if(is_object($value)): ?>

	                                
                                      
                                                
                                       <td><?php echo e($value->product_category); ?></td>
                                       <td><?php echo e($value->product_subcategory); ?></td>
                                       <td>
						                   <a class="btn btn-primary" href="/admin/<?php echo e($value->product_id); ?>/edit">Edit</a>
						                </td>
						                <td>
						                   <a class="btn btn-primary" href="/admin/<?php echo e($value->product_id); ?>/delete">Delete</a>
						                </td>  

                                     

	                                   
		                             <?php elseif(!is_object($value)): ?>
		                              
			                                <?php if($key==="product_id"): ?>
		                                            
		                                        <td>
		                                          <?php echo e($value); ?>

		                                       </td>
		                                      

			                               <?php endif; ?>
	                                     
			                                <?php if($key==="product_name"): ?>
		                                            
		                                        <td>
		                                          <?php echo e($value); ?>

		                                       </td>
		                                      

			                               <?php endif; ?>

			                                <?php if($key==="product_price"): ?>
		                                            
		                                        <td>
		                                          <span>$<?php echo e(number_format($value,2)); ?></span>
		                                       </td>
		                                      

			                               <?php endif; ?>




			                               <?php if($key==="product_description"): ?>
		                                            
		                                        <td>
		                                          <?php echo e($value); ?>

		                                       </td>
		                                      

			                               <?php endif; ?>



			                                <?php if($key==="product_image"): ?>
			                                   
			                                
		                                        <td>
		                                        <img class="product_image_admin" src="<?php echo e(url('/')); ?>/<?php echo e($value); ?>" alt="" />

		                                       </td>
		                                      

			                               <?php endif; ?>

			                               <?php if($key==="created_at"): ?>
		                                            
		                                        <td>
		                                          <?php echo e($value); ?>

		                                       </td>
		                                      

			                               <?php endif; ?>


                                           
			                               <?php if($key==="updated_at"): ?>
		                                            
		                                        <td>
		                                          <?php echo e($value); ?>

		                                       </td>
		                                      

			                               <?php endif; ?>


			                               <?php if($key==="product_size"): ?>
		                                           
		                                        <td>
		                                        
		                                         <?php $__currentLoopData = unserialize($value); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizes): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                                                 <?php echo e($sizes); ?>

		                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?> 
		                                       </td>
		                                      

			                               <?php endif; ?>
			                                

                                       

                           	
		                             <?php else: ?>

	                           <?php endif; ?>

	                       <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	                      
                         </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				   </tbody>
					
	</table>
      </div>
  	      
  	    
  </div>
	


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>